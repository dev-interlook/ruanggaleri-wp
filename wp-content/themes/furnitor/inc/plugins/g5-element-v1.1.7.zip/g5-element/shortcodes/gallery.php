<?php
// Do not allow directly accessing this file.
if (!defined('ABSPATH')) {
    exit('Direct script access denied.');
}
class WPBakeryShortCode_G5Element_Gallery extends G5Element_ShortCode_Base {
}