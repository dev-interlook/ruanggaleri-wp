Changelog
=========
#### 1.1.7 - June 11, 2021
* Update widget elementor

#### 1.1.6 - May 06, 2021
* Update layout 03, layout 04, layout 05 for single product

#### 1.1.5 - April 19, 2021
* Update product skin 03

#### 1.1.4 - April 07, 2021
* Fix display product image in cart page.

#### 1.1.3 - December 29, 2020
* Fix style line ending both DOS and UNIX

#### 1.1.2 - December 28, 2020
* Fix error order by in shortcode product

#### 1.1.1 - December 10, 2020
* Fix filter category

#### 1.1.0- September 22, 2020
* Update display wishlist button in single product

#### 1.0.9- September 18, 2020
* Update template cross-sells version 4.4.0

#### 1.0.8 - July 29, 2020
* Fix register meta for attributes product

#### 1.0.7 - May 04, 2020
* Fix save attributes in product page
* Compatible with woocommerce 4.0.1

#### 1.0.6 - April 01, 2020
* Fix warning variable image_size in template  woocommerce/content-product_cat.php

#### 1.0.0 - February 25, 2017
* Inital Version