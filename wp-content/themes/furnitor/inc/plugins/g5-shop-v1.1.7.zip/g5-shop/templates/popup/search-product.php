<?php
// Do not allow directly accessing this file.
if (!defined('ABSPATH')) {
    exit('Direct script access denied.');
}
?>
<div id="g5shop__search_product_popup" class="g5core-search-popup g5shop__search-product-popup mfp-hide mfp-with-anim">
    <?php g5shop_template_search_product(); ?>
</div>
