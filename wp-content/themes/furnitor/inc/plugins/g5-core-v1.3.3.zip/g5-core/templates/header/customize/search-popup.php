<div id="g5core_search_popup" class="g5core-search-popup mfp-hide mfp-with-anim">
	<?php G5CORE()->get_template( 'header/customize/search-form.php' ); ?>
</div>