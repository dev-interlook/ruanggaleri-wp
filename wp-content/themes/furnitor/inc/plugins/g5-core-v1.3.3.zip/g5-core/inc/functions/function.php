<?php
/**
 * Load helper functions
 */
G5CORE()->load_file(G5CORE()->plugin_dir('inc/functions/hook.php'));
G5CORE()->load_file(G5CORE()->plugin_dir('inc/functions/helper.php'));
G5CORE()->load_file(G5CORE()->plugin_dir('inc/functions/vendor-wsl.php'));
G5CORE()->load_file(G5CORE()->plugin_dir('inc/functions/options.php'));
G5CORE()->load_file(G5CORE()->plugin_dir('inc/functions/template.php'));
G5CORE()->load_file(G5CORE()->plugin_dir('inc/functions/color.php'));
G5CORE()->load_file(G5CORE()->plugin_dir('inc/functions/font-awesome.php'));
G5CORE()->load_file(G5CORE()->plugin_dir('inc/functions/font-svg.php'));
G5CORE()->load_file(G5CORE()->plugin_dir('inc/functions/elementor.php'));
